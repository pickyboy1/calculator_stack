#include"calculator.h"
#include"Stack.h"
#include<iostream>
using namespace std;
int main() {
	calculator cal;
	double result;
	result=cal.exce('\n');
	cout << result;
}